package com.liquibase.example.LiquibaseExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LiquibaseExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(LiquibaseExampleApplication.class, args);
	}

}
