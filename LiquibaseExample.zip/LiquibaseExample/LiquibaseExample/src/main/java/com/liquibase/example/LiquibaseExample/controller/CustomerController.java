package com.liquibase.example.LiquibaseExample.controller;

import com.liquibase.example.LiquibaseExample.entity.Person;
import com.liquibase.example.LiquibaseExample.repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/person")
public class CustomerController {

    @Autowired
    PersonRepository personRepository;

    @PostMapping
    public String createPerson(@RequestBody Person requestPerson) {
        personRepository.save(requestPerson);
        String nameToReturn = personRepository.findByName(requestPerson.getName());
        return nameToReturn + " Saved successfully";
    }

    @GetMapping
    public List<Person> getAllPerson() {
        return (List<Person>) personRepository.findAll();
    }

    @PutMapping("/{id}")
    public String updatePerson(@PathVariable Integer id, @RequestBody Person updatePerson){
        Optional<Person> personOp = personRepository.findById(id);
        if(!personOp.isPresent()) {
            return "No Person exist by "+id;
        }
        Person existingPerson = personOp.get();
        existingPerson.setName(updatePerson.getName());
        existingPerson.setPAN(updatePerson.getPAN());
        existingPerson.setAddress(updatePerson.getAddress());

        personRepository.save(existingPerson);
        return updatePerson.getName() + " updated successfully";
    }
}
