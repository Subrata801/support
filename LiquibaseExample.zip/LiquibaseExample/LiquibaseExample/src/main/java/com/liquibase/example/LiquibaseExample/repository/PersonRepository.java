package com.liquibase.example.LiquibaseExample.repository;

import com.liquibase.example.LiquibaseExample.entity.Person;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface PersonRepository extends JpaRepository<Person, Integer> {

    @Query("SELECT name FROM Person p WHERE p.name LIKE %:name%")
    String findByName(String name);

}
