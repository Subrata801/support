package com.liquibase.example.LiquibaseExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiquibaseExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
